## MyricaM 改版履歴  

#### Version 2.010.20160103  
　　Inconsolata : Inconsolata-Regular.ttf (1.016 Google Fonts)  
　　Mgen+       : mgenplus-1m-light.ttf (1.059.20150602)  

* 一部の記号がフォントサイズによっては等幅にならない現象の修正  


#### Version 2.009.20151218  
　　Inconsolata : Inconsolata-Regular.ttf (1.016 Google Fonts)  
　　Mgen+       : mgenplus-1m-light.ttf (1.059.20150602)  

* Mgen+のバージョンアップに追従して更新  
* Inconsolataのバージョンアップに追従して更新  

* font.os2_typodescent, font.hhea_descent の指定に誤りがあったので修正  

* 一部の記号 ()[]{}| がフォントサイズによっては等幅にならない現象の修正  

* ひらがな・カタカナのヒンティングの品質が良くなかったので、取りやめ (ASCII文字については従来通り有効)  


#### Version 2.008.20151209  
　　Inconsolata : Inconsolata-Regular.ttf (1.013 Google Fonts)  
　　Mgen+       : mgenplus-1m-thin.ttf (1.059.20150116)  

* ー(長音記号)の文字を－(マイナス)と区別するため、字形を変更した


#### Version 2.007.20150313  
　　Inconsolata : Inconsolata-Regular.ttf (1.013 Google Fonts)  
　　Mgen+       : mgenplus-1m-thin.ttf (1.059.20150116)  

* かな文字のヒンティングの調整


#### Version 2.006.20150301  
　　Inconsolata : Inconsolata-Regular.ttf (1.013 Google Fonts)  
　　Mgen+       : mgenplus-1m-thin.ttf (1.059.20150116)  

* プロポーショナル の文字幅を 全角かな文字:90%、その他の全角文字:95% に調整


#### Version 2.005.20150223  
　　Inconsolata : Inconsolata-Regular.ttf (1.013 Google Fonts)  
　　Mgen+       : mgenplus-1m-thin.ttf (1.059.20150116)  

* Mgen+ をベースとしたフォントを復活

* Mgen+ をベースとした文字の改変  
　　ASCII文字以外を水平/垂直方向に太字化(H:20, V:5)  
　　「ぱぴぷぺぽパピプペポ」の半濁点を大きく  
　　「カ力 エ工 ロ口 ー一 ニ二」（カタカナ・漢字）の区別  
　　「～〜」（FULLWIDTH TILDE・WAVE DASH）の区別  
　　ひらかな/カタカナへのヒント情報の付加


#### Version 1.012.20141102  
　　Inconsolata : Inconsolata-Regular.ttf (1.013 Google Fonts)  
　　Mgen+       : mgenplus-1m-regular.ttf (1.058.20140808 (20140828)  
　　Migu        : migu-1m-regular.ttf (2013.0617 (20130617)  

* Mgen+ をベースとした最終版

* 改変内容  
　　「 * l – — 」の文字をオリジナルに変更  
　　「 | D r 」の文字を Inconsolata に内包されている別のグリフで置換え   
　　「 + - = ~ 」の文字の位置を変更    
　　「 " ' ` , . : ; 」の文字を拡大   
　　ASCII文字以外を水平方向に太字化(weight:10)  
　　「ぱぴぷぺぽパピプペポ」の半濁点を大きく  
　　「カ力 エ工 ロ口 ー一 ニ二」（カタカナ・漢字）の区別  
　　「～〜」（FULLWIDTH TILDE・WAVE DASH）の区別  
　　ひらかな/カタカナへのヒント情報の付加
